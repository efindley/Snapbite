SnapBite — iPhone Home Screen app package

WHAT THIS PACKAGE DOES
- Includes the app page, install manifest, app icons, and offline service worker.
- Once hosted over HTTPS, Safari on iPhone can add it to the Home Screen and open it in an app-like standalone view.
- Food entries are stored in the browser on that device. This package does NOT yet connect to an AI vision API, so photo-based calorie estimation is manual.

IMPORTANT
A website must host these files over HTTPS before the iPhone can install it as a web app. This package cannot publish itself or create a public website without a hosting account/permission.

EASIEST FREE PUBLISH ROUTE (GitHub Pages)
1. On a computer, sign in to GitHub and create a new public repository named `snapbite`.
2. Upload all files and folders in this package (index.html must be at the repository root).
3. In the repository, open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub to provide the published HTTPS site address.
6. On the iPhone, open that address in Safari.
7. Tap Share (square with upward arrow) → Add to Home Screen → Add.

If GitHub Pages is enabled, your site address usually resembles:
https://YOUR-USERNAME.github.io/snapbite/
Replace YOUR-USERNAME with your GitHub username. Do not use that example address until your actual site is published.

The HTML can be edited later and uploaded again to update the app.
